class Osoba:
    kolor_oczu = "brązowe"

    # opis stanu - konstruktor funkcji
    def __init__(self, imie, nazwisko, wiek, waga, wzrost):
        self.imie = imie  # kontekst.nazwa_zmiennej = nazwa_parametru
        self.nazwisko = nazwisko
        self.wiek = wiek
        self.waga = waga
        self.wzrost = wzrost
        self.__info__()


    # opis zachowania -> funkcje klasy -> metody
    @staticmethod
    def __info__():
        print("nowa osoba została utworzona......")

    def print_osoba(self):
        print(f"dane osoby - imię: {self.imie}, nazwisko: {self.nazwisko}, wiek: {self.wiek} lat, "
              f"waga: {self.waga} kg, wzrost: {self.wzrost} cm")

    def wiekza10lat(self):
        return self.wiek + 10

    def czypracownik(self):
        return False


os1 = Osoba("Jan","Kot",44,99,174)
os1.print_osoba()
print(f"kolor oczu: {os1.kolor_oczu}")
print(f"wiek za 10 lat: {os1.wiekza10lat()} lat")
print(f"czy osoba jest pracownikiem? {os1.czypracownik()}")

print("************************************")
os2 = Osoba("Olga","Knot",33,52,171)
os2.print_osoba()
os2.kolor_oczu = "niebieski"
print(f"kolor oczu: {os2.kolor_oczu}")
print(f"wiek za 10 lat: {os2.wiekza10lat()} lat")
print(f"czy osoba jest pracownikiem? {os2.czypracownik()}")

os3 = Osoba("Eryk","Nowak",11,45,145)
print(f"kolor oczu: {os3.kolor_oczu}")
os3.__info__()

class Pracownik(Osoba):

    #konstruktor z dziedziczeniem
    def __init__(self,imie, nazwisko, wiek, waga, wzrost,firma,stanowisko,latapracy,wynagrodzenie):
        super().__init__(imie, nazwisko, wiek, waga, wzrost)
        self.firma=firma
        self.stanowisko = stanowisko
        self.latapracy = latapracy
        self.wynagrodzenie = wynagrodzenie

    def print_pracownik(self):
        print(f"dane pracownika -> firma:{self.firma}, stanowisko pracy: {self.stanowisko}, "
              f"lata pracy: {self.latapracy}, wynagrodzenie: {self.wynagrodzenie} zł")

    def czypracownik(self):
        return True

print("_____________pracownicy________________")
pr1 = Pracownik("Olga","Nowak",40,56,176,"ABC","dyrektor",6,10700)

pr1.print_osoba()
pr1.print_pracownik()
print(f"kolor oczu: {pr1.kolor_oczu}")
print(f"wiek za 10 lat: {pr1.wiekza10lat()} lat")
print(f"czy osoba jest pracownikiem? {pr1.czypracownik()}")

class Ekstra:
    pass

class Sport:

    def __init__(self,dyscyplina,lata_upr,best_wynik):
        self.dycyplina = dyscyplina
        self.lata_upr = lata_upr
        self.best_wynik = best_wynik

    def infosport(self):
        print(f"dysycyplina: {self.dycyplina}, lata uprawiania: {self.lata_upr}, życiówka: {self.best_wynik}")


class Student(Pracownik,Sport,Ekstra):

    #konstruktor z wielodziedziczeniem
    def __init__(self,imie, nazwisko, wiek, waga, wzrost,idstudenta,kierunek,rok_ukon,
                 firma="",stanowisko="",latapracy="",wynagrodzenie="",dyscyplina="",lata_upr="",best_wynik=""):
        Pracownik.__init__(self,imie, nazwisko, wiek, waga, wzrost,firma,stanowisko,latapracy,wynagrodzenie)
        Sport.__init__(self,dyscyplina,lata_upr,best_wynik)
        self.idstudenta = idstudenta
        self.kierunek = kierunek
        self.rok_ukon = rok_ukon

    def print_student(self):
        print(f"dane studenta - id: {self.idstudenta}, kierunek: {self.kierunek}, rok ukończenia"
              f"studiów: {self.rok_ukon}")

    def czypracownik(self):
        return self.firma != ""

print("____________studenci_______________________")
s1 = Student("Nadia","Nowak",22,60,178,45435,"budowa mostów",2023)

s1.print_osoba()
s1.print_student()

print(f"kolor oczu: {s1.kolor_oczu}")
print(f"wiek za 10 lat: {s1.wiekza10lat()} lat")
print(f"czy osoba jest pracownikiem? {s1.czypracownik()}")

print("**********************************************")

s2 = Student("Piotr","Kot",23,102,190,2333231,"informatyka",2022,"Krzak SA","junior deweloper",
             1,3400)

s2.print_osoba()
s2.print_student()
s2.print_pracownik()

print(f"kolor oczu: {s2.kolor_oczu}")
print(f"wiek za 10 lat: {s2.wiekza10lat()} lat")
print(f"czy osoba jest pracownikiem? {s2.czypracownik()}")

print("**********************************************")
#student który nie jest pracownikiem ale jest sportowcem
# użyj wszytkich dostępnych metod dla instancji s3



