def info():
    print("to jst ważna informacja")

info()
#uruchom 25 razhy funkcję info()

for _ in range(1,26):
    info()

def obywatel(nrtelefonu,kraj="Polska"):
    print(f"kraj pochodzenia: {kraj}, telefon: {nrtelefonu}")

obywatel(4234234,"Urugwaj")
obywatel(54353454543,"Holandia")
obywatel(356546546,"Grecja")
obywatel(2546546546,"Norwegia")
obywatel(565465645)



f =10
def oblicz(a,b,x):
    global f
    f = (a+b)*x + f + fx(b)
    return f

def fx(k):
    return k**5

print(oblicz(3,6,7))
print(f)
print(oblicz(4,3,True))

def miasta(miasto3,miasto2="Radom",miasto1="Kraków"):
    print(f"miasto tygodnia: {miasto1}, drugie miejsce: {miasto2}, trzecie miejsce: {miasto3}")

miasta("Toruń","Wrocław","Warszawa")
miasta("Toruń","Wrocław")
miasta("Kielce")
miasta("Kielce",None,"Gdańsk")
miasta("Kielce",miasto1="Gdańsk")

def zamki(id,*zamek,rabat):
    print(f"zamek tygodnia: {zamek[0]}, rabat: {rabat}zł, drugie miejsce: {zamek[1]}, trzecie miejsce: {zamek[2]}")

zamki(1,"Malbork","Ogrodzieniec","Będzin",rabat=30)
zamki(2,"Janowiec","Malbork","Czersk","Ogrodzieniec","Będzin",rabat=10)



