drzewa = {"buk", "jesion", "dąb", "sosna", "baobab","jabłoń","dąb"}
print(drzewa)
print(drzewa)
print(drzewa)

for d in drzewa:
    print(d)

print("jesion" in drzewa)
print("osika" in drzewa)

drzewa.add("osika")
print(drzewa)

drzewa.update(["świerk","wierzba","topola","śliwa"])

print(drzewa)

liczby =[45,6,6,2,23,23,6,6,12,3,6,6,16,6]

lp = liczby.pop()

print(lp)
print(liczby)
setliczby = set(liczby)
print(setliczby)
liczby = list(setliczby)
print(liczby)

drzewa.remove("jesion")
print(drzewa)

drzewa.discard("jojoba")
drzewa.discard("osika")

print(drzewa)

drzewap = drzewa.pop()
print(drzewap)
print(drzewa)
