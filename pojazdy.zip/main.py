#Stwórz dwa interfejsy (ABCMeta): IOpis, IKoszty
#IOpis ma zawierać metody abstrakcyjne: opisujące: 1 (infopojazd) - podstawowe informacje o pojeździe (marka, model, przebieg,rocznik)
# ,2 (infosilnik) -  informacje o silniku(rodzaj, poj,moc)
#IKoszty - dwie metody: 1 (spalanie na 100): wyznaczanie wartości spalania na 100km,
#2 - (kosztprzejzadu) - obliczanie kosztów przejazdu na określonej trasie z uwględnieniem wartości splania,
# oraz cena paliwa za 1l
#Stwórz klasę Pojzad z dziedziczeniem obu interfejsów
#zdefiniuj wszysktie metody
#Stwórz dwa różne przypadki - obiwekty klasy Pojzad i wypisz wszystkie możliwe wartości

from abc import ABCMeta, abstractmethod

class IOpis:

    __metaclass__ = ABCMeta

    @abstractmethod
    def infopojazd(self,marka,model,przebieg,rocznik):raise NotImplementedError

    @abstractmethod
    def infosilnik(self,rodzaj,poj,moc):raise NotImplementedError

class IKoszty:

    __metaclass__ = ABCMeta

    @abstractmethod
    def spalmna100(self,spal100):raise NotImplementedError

    @abstractmethod
    def kosztyprzejzadu(self,spal100,trasa,cena_l):raise NotImplementedError

class Pojazd(IOpis,IKoszty):

    def __init__(self,id,termin_badania, cena_kat):
        self.id = id
        self.termin_badania = termin_badania
        self.cena_kat = cena_kat

    def status_pojazdu(self):
        return f"id: {self.id}, termin badania technicznego: {self.termin_badania}, cena: {self.cena_kat} zł"

    def infopojazd(self, marka, model, przebieg, rocznik):
        return f"Opis pojazdu -> marka {marka}, model: {model}, przebieg: {przebieg} km, rocznik: {rocznik}"

    def infosilnik(self, rodzaj, poj, moc):
        return f"opis silnika -> rodzaj: {rodzaj}, pojemność: {poj}, moc: {moc} KM"

    def spalmna100(self, spal100):
        return spal100

    def kosztyprzejzadu(self, spal100, trasa, cena_l):
        return spal100*(trasa/100)*cena_l


p1 = Pojazd(45,"2022-10-10",58000)

print(p1.status_pojazdu())
print(p1.infopojazd("Peugeot","508",78900,2017))
print(p1.infosilnik("diesel",2.0,170))
print(f"spalanie na 100 km: {p1.spalmna100(8.8)}")
print(f"koszt przejazdu: {p1.kosztyprzejzadu(p1.spalmna100(8.8),556,7.45)}")

p2 = Pojazd(122,"2022-06-17",112000)

print(p2.status_pojazdu())
print(p1.infopojazd("Jeep","Cherokee",122900,2019))
print(p1.infosilnik("diesel",4.8,280))
print(f"spalanie na 100 km: {p1.spalmna100(14.7)}")
print(f"koszt przejazdu: {p1.kosztyprzejzadu(p1.spalmna100(14.7),677,7.45)}")