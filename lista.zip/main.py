print("kolekcje - lista")
kraj = ["Polska","Niemcy","Hiszpania","USA","Japonia"]
print(kraj[3])
print(kraj)
print(kraj[2:4])
kraj.append("Włochy")
print(kraj)
kraj.sort()
print(kraj)
kraj.reverse()
print(kraj)
kraj.sort(reverse=True)
print(kraj)

s = "lajkonik"
print(s)
print(s[0])
print(s[2])
print(s[0:3])
print(s[:4])
print(s[2:])
print(s[-1])

print(kraj[1][2])
liczby = [2,67,112,45,-9,0,12,56,78,1,-10,0,112,112,1]
liczby.sort(reverse=True)
print(liczby)
liczby.remove(12) #usuwanie po wartości
print(liczby)

del liczby[1] #usuwanie po indeksie
print(liczby)

sklepzoo = [["pies","kot","papuga","mysz","szynszyla"],[6500,2300,8700,35,180]]
print(sklepzoo[0])
print(sklepzoo[0][2]," - ",sklepzoo[1][2],"zł")
print(sklepzoo[0][2] + " - " + str(sklepzoo[1][2]) + " zł")

cena = "zwierzę: {}, cena: {} zł"
print(cena.format(sklepzoo[0][0],sklepzoo[1][0]))

miasto = "Kraków"
wiek = 33
imie = "Olga"

print(f"dane klienta - imię:{imie}, wiek: {wiek} lat, miasto: {miasto}.")

opis = "mojedane"
wart = 8.3424434

print('%-30s = %.2f' %(opis,wart))

cyfry = [2,6,7,1]
liczby = liczby + cyfry #konkatencja tablic
print(liczby)

liczby = liczby*2

print(liczby)

litery = ['a','b','c','d','e','f','g','h']

print(f"przed zmianą {litery}")
litery[2:7] = [99,33,3242]
print(f"po zmianie {litery}")

litery_m = litery
litery_p = list(litery)
litery_q = litery[:]

print(f"przed zmianą {litery}")
print(f"przed zmianą {litery_m}")

litery[:] = [1001,1002,1006,1010]

print(f"po zmianą {litery}")
print(f"po zmianą {litery_m}")
print(f"po zmianą {litery_p}")
print(f"po zmianą {litery_q}")

#zadanie: stwórz dwie tablice parz i nieparz, uzupełnij je o kolory odpwiednio
# z pozycji parzystej i nieparzystej tablicy kolory "

kolory = ["czerwony","czarny","biały","fioletowy","zółty","zielony"]

parz = kolory[::2]
nieparz = kolory[1::2]

print(parz)
print(nieparz)


#zadanie: wyświetl zadany tekst odwrotnie, zmiń bieg liter
w1 = "kajak"
w2 = "pomarańcza"

