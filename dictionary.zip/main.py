#słownik => dictionary(dict) =>(klucz,wartość)

auto = {
    "marka":"Ford",
    "model":"Mustang",
    "rocznik":1974
}

print(auto)
m = auto["model"]
print(m)

m = auto.get("model")
print(m)

auto["rocznik"] = 2018
print(auto)

auto["pojemnosc"] = 4.4
print(auto)

print(auto.items())
print(auto.keys())
print(auto.values())

for x in auto:
    print(x)

for y in auto:
    print(auto[y])

for x,y in auto.items():
    print(f"{x}: {y}")

samochody = {
    "sam1":{
    "marka":"Ford",
    "model":"Mustang",
    "rocznik":1974
    },
    "sam2":{
    "marka":"Opel",
    "model":"Insignia",
    "rocznik":2021
    },
    "sam3":{
    "marka":"Peugeot",
    "model":"508",
    "rocznik":2019
    }
}

print(samochody)

print(samochody['sam2']['marka'])